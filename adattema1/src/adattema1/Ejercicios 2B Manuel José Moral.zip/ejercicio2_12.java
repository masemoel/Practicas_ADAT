package adattema1;

/*
 * Manuel José Moral Eliche
 * Ejercicio 2.12 - Acceso a datos
 */
public class ejercicio2_12 {
	public static void main(String[] args) {
		
	}
}